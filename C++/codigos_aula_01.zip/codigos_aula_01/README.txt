############################################################
Cada um dos arquivos da aula deve ser compilado separadamente.

Por exemplo: 

$ g++ ex0_hello_world.cpp -o ex0_hello_world

Compilado o código, o arquivo gerado pode ser executado.

$ ./ex0_hello_world

############################################################
É possível compilar sem fornecer o nome do executável. Nesse caso, o
arquivo gerado terá nome "a.out".

Por exemplo: 

$ g++ ex0_hello_world.cpp

Compilado o código, o arquivo gerado pode ser executado.

$ ./a.out
